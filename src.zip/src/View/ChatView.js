import React from "react";

const ChatView: React.FC = () => {

    return (
        <div>
            <h1>CHAT</h1>
        </div>
    );
};
export default ChatView;