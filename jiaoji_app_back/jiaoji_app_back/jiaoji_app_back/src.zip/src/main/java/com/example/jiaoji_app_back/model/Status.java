//package com.example.jiaoji_app_back.model;

import com.example.jiaoji_app_back.entity.ActivityDetails;
//
//public enum Status {
//    NOT_RELEASE("notRelease"),
//    TODO("todo"),
//    PASS("pass"),
//    REJECTED("rejected"),
//    SIGN("sign"),
//    PROCESS("process"),
//    OVER("over");
//
//    private final String value;
//
//    Status(String value) {
//        this.value = value;
//    }
//
//    public String getValue() {
//        return value;
//    }
//
//    public static Status fromValue(String value) {
//        for (Status status : Status.values()) {
//            if (status.getValue().equalsIgnoreCase(value)) {
//                return status;
//            }
//        }
//        throw new IllegalArgumentException("Invalid Status value: " + value);
//    }
//}
