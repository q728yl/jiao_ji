package com.example.jiaoji_app_back;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JiaojiAppBackApplication {

	public static void main(String[] args) {
		SpringApplication.run(JiaojiAppBackApplication.class, args);
	}

}
