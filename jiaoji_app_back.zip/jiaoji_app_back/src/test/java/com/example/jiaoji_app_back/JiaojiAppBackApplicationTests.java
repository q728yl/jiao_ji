package com.example.jiaoji_app_back;


import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JiaojiAppBackApplicationTests {

	@Test
	void contextLoads() {
		String s = "pass";
	}


}
