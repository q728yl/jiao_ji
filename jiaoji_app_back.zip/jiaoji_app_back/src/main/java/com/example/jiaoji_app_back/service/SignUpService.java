package com.example.jiaoji_app_back.service;
import com.example.jiaoji_app_back.entity.ActivitySignup;

public interface SignUpService {

    boolean SignUp(Integer userID, Integer actId);

}