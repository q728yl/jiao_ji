package com.example.jiaoji_app_back.dao;

public interface SignupDao {
    boolean SignUp(Integer userID, Integer actId);
}