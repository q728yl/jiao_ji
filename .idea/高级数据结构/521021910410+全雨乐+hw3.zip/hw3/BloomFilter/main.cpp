#include <iostream>
#include <iomanip>
#include <vector>
#include <ostream>
#include <iterator>
#include <algorithm>]


#include <ctime>
#define N   100
#define M   300
using namespace std;
hash<double>hash_1;
int hash1(int x){
    return (hash_1(x)) % M;
};
int main() {
    int hashTable[M]{};
    vector<int> vec{};
    vector<int> vec2{};//原始插入序列
    vector<int> vec3{};//检测序列
    //生成一个规模为2*n的插入序列，放入vec中,前n为原始插入序列，后n为检测序列
    srand((unsigned int) time(NULL));
    do {
        int t = rand() % (2 * M);
        auto result = find(vec.begin(), vec.end(), t);
        if (result == vec.end())
            vec.push_back(t);
    } while (vec.size() != 2*N);

    for (int i = 0; i < N; i++) {
        vec2.push_back(vec[i]);
    }
    for (int i = N; i < 2 * N; i++) {
        vec3.push_back(vec[i]);
    }
    for (int i = 0; i < 2 * N; i++)
        cout << vec[i] << " ";
    cout << endl;
    cout << vec.size() << " " << vec2.size() << " " << vec3.size() << endl;
    //hash入hashTable
    for (int i = 0; i < N; i++) {
        int tmp = vec2[i];
        hashTable[hash1(tmp)] = 1;
        hashTable[hash1(tmp + 1)] = 1;
//        hashTable[hash1(tmp + 2)] = 1;
//        hashTable[hash1(tmp + 3)] = 1;
//        hashTable[hash1(tmp + 4)] = 1;
    }
    for (int i = 0; i < M; i++)
        cout << hashTable[i] << " ";
    cout << endl;
    int count = 0;
    int c = N;
    for (int i = 0; i < N; i++) {
        int t = vec3[i];
        cout << t << " ";
        auto result = find(vec2.begin(), vec2.end(), t);
        //找到了
        if (result != vec2.end()) {
            c--;
            cout << "是重复元素" << " ";//当然不可能重复，只是验证一下
        } else {
            if (hashTable[hash1(t)] == 1 && hashTable[hash1(t + 1)] == 1 ) {
                cout << "不在原始数据里，但hash到了，假阳性" << " ";
                count++;
            }
        }
        cout << endl;
    }
    cout << endl;
    cout<<"2个hash函数时："<<endl;
    cout << "检验元素个数为 "<< c <<"，M为 "<<M <<"时，误报元素个数为 " << count<<"，假阳性比例为 "<<float(count)/float(c);

};