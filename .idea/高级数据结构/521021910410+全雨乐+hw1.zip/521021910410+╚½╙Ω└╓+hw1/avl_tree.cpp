#include<iostream>
#include <ctime>
#include<cstdlib>
#include <stack>
#include <algorithm>
using namespace std;

//template <typename T>
class node{
public:
    int key;
    int height;
    node * left = nullptr;
    node * right =nullptr;
//    node(){
//        height=1;
//    }
//        static node * newNode(int x){
//            node * h =new node();
//            h->height = 1;
//            h->key = x;
//            h->right = nullptr;
//            h->left = nullptr;
//            return h;
//        }
//    static node * newNode(node * head, int k){
//         head =new node();
//         head->height = 1;
//         head->key = k;
//         head->left = nullptr;
//         head->right = nullptr;
//         return head;
//    }
};

//template <typename T>
class AVL{
public:
    node * root = nullptr;
    void insert(int x){
        root=insertUtil(root, x);

    }

    void remove(int x){
        root=removeUtil(root, x);

    }

    node * search(int x){
        return searchUtil(root,x);
    }

    void inorder(){
        inorderUtil(root);
        cout<<endl;
    }
    node * leftAndRightRotation(node* t) {
        t->left = leftRotation(t->left);
        return rightRotation(t);
    }

    node * rightAndLeftRotation(node* t) {
        t->right = rightRotation(t->right);
        return leftRotation(t);
    }
    int height(node * head){
        if(head==nullptr) return 0;
        return head->height;
    }
//危机节点为head
    node * rightRotation(node * head){
        node * newhead = head->left;
        head->left=NULL;
        head->left = newhead->right;
        newhead->right = head;
        head->height = 1+max(height(head->left), height(head->right));
        newhead->height = 1+max(height(newhead->left), height(newhead->right));
        return newhead;
    }

    node * leftRotation(node * head){
        node * newhead = head->right;
        head->right =NULL;
        head->right = newhead->left;
        newhead->left = head;
        head->height = 1+max(height(head->left), height(head->right));
        newhead->height = 1+max(height(newhead->left), height(newhead->right));
        return newhead;
    }

    // Traverse and print AVL tree
    void inorderUtil(node * head){
        if(head==nullptr) return ;
        inorderUtil(head->left);
        cout<<head->key<<" ";
        inorderUtil(head->right);
    }
//return root
    node * insertUtil(node * head, int x) {
        // TODO: finish insertUtil

        if (head == nullptr){
            head = new node();
            head->right = nullptr;
            head->left = nullptr;
            head->key = x;
            head->height = 1;
            return head;
        }
        if (head->key > x) {
            head->left = insertUtil(head->left, x);
            if (height(head->left) - height(head->right) == 2) {
                if (x < head->left->key)
                    head = rightRotation(head);
                else if (x > head->left->key)
                    head = leftAndRightRotation(head);
            }
        } else if (head->key < x) {
            head->right = insertUtil(head->right, x);
            if (height(head->right) - height(head->left) == 2) {
                if (x < head->right->key)
                    head = rightAndLeftRotation(head);
                else if (x > head->right->key)
                    head = leftRotation(head);

            }
        } else{

        }



        head->height=1+max(height(head->left), height(head->right));

        return  head;

    }

    node * removeUtil(node * head, int x) {
        // TODO: finish removeUtil
        stack<node *> s;
        if (head == nullptr)
            return nullptr;
        if (x < head->key) {
            s.push(head);
            head->left = removeUtil(head->left, x);
        } else if (x > head->key) {
            s.push(head);
            head->right = removeUtil(head->right, x);
        } else {
            s.push(head);
            if (head->left != nullptr && head->right != nullptr) {
                node *parent = head->right;
                s.push(parent);
                while (parent->left != nullptr) {
                    parent = parent->left;
                    s.push(parent);
                }
                head->key = parent->key;//右子树最小值放入被删节点位置
                head->right = removeUtil(head->right, parent->key);
            } else if (head->left != nullptr) {
                head = head->left;
                s.push(head);

            } else if (head->right != nullptr) {
                head = head->right;
                s.push(head);
            } else {
                return nullptr;
            }

        }
        head->height = 1 + max(height(head->left), height(head->right));
        return head;


//
//        node * he = s.top();
//            do {
//
////            //删除完成，接下来看高度是否平衡
//                do{
//                    if (s.top() == nullptr)
//                    s.pop();
//                }while(s.top()== nullptr);
//                   // return nullptr;
////        head->height = 1+max(height(head->left), height(head->right));
//                he = s.top();
//                if (height(s.top()->left) - height(s.top()->right) >= 2) {
//                    //相当于插入在左子树上
//                    if (height(s.top()->left->left) - height(s.top()->left->right) >= 2) {
//                        //LL
//                        he= rightRotation(s.top());
//                    } else {
//                        //LR
//                        he= leftAndRightRotation(s.top());
//                    }
//
//
//                } else if (height(s.top()->right) - height(s.top()->left) >= 2) {
//                    //相当于插入在右子树上
//                    if (height(s.top()->right->right) - height(s.top()->right->left) >= 2) {
//                        //RR
//                        return leftRotation(s.top());
//                    } else {
//                        //RL
//                        return rightAndLeftRotation(s.top());
//                    }
//
//                } else {}
//                if
//                s.top()->height = 1 + max(height(s.top()->left), height(s.top()->right));
//                he = s.top();
//
//            } while (!s.empty());
//        //return head;
//    if(he == nullptr)
//        return nullptr;
//    he->height=1+max(height(he->left), height(he->right));
//    return he;
    }
//        node* parent = nullptr;
//        node* p = head, * q = nullptr;
//        stack<node*> st;
//        while (p) {		//先找到节点，存储轨迹
//            if (p->key ==x)
//                break;
//            parent = p;
//            st.push(parent);
//            if (x > p->key)
//                p = p->right;
//            else
//                p = p->left;
//        }
//        if (p==nullptr)//删除目标不存在
//            return NULL;
//        //删除节点
//        if (p->left && p->right) {//删除目标左右皆有
//            parent = p;
//            q = p->left;
//            st.push(parent);
//            while (q->right) {
//                parent = q;
//                st.push(parent);
//                q = q->right;
//            }
//            p->key = q->key;
//            p = q;//转化为删前驱
//        }
//        //p是删除目标,q是删除目标的子女节点
//        if (p->left)
//            q = p->left;
//        else
//            q = p->right;
//        bool Isleft = false;
//        if (parent==nullptr)//删除目标是整棵AVL的根节点
//            head = q;
//        else {
//            //断开p节点，链接它的子女q
//            if (parent->left == p) { //删除目标是左孩子
//                parent->left = q;
//                Isleft = true;
//            }
//            else//删除目标是右孩子
//                parent->right = q;
//        }
//        //调整平衡
//        bool isbanlanced = false;
//        while (!st.empty()) {
//            parent = st.top();
//            st.pop();
//            if(Isleft)
//                ++parent->bf;
//            else
//                --parent->bf;
//            if (parent->bf == 1 || parent->bf == -1)//平衡
//                break;
//            if (0 == parent->bf) { //向上回溯调整
//                q = parent;
//                if(st.size())//重置isleft
//                    Isleft = st.top()->left == q ? true : false;
//            }
//            else {//parent失衡
//                if (parent->bf > 0)//令q指向较高的树
//                    q = parent->right;
//                else
//                    q = parent->left;
//                if (q->bf == 0){//单旋转
//                    if (parent->bf < 0){
//                        RotateR(parent);
//                        parent->bf = 1;
//                        parent->right->bf = -1;
//                    }
//                    else{
//                        RotateL(parent);
//                        parent->bf = -1;
//                        parent->left->bf = 1;
//                    }
//                    isbanlanced = true;
//                }
//                else {
//                    if (parent->bf < 0) {
//                        if (q->bf < 0)  //   /
//                            RotateR(parent);
//                        else           //   <
//                            RotateLR(parent);
//                    }
//                    else {
//                        if (q->bf > 0)  //   \
//							RotateL(parent);
//                                else           //   >
//                        RotateRL(parent);
//                    }
//                }
//                //重新链接
//                if (st.empty())
//                    t = parent;
//                else {
//                    q = st.top();
//                    if (parent->val < q->val)
//                        q->left = parent;
//                    else
//                        q->right = parent;
//                }
//                if (isbanlanced)
//                    break;
//            }
//        }
//        delete p;
//        return true;
//
////执行到此处，p要么为预想的删除目标，要么为nullptr（即不存在）
////下一步应该是判断删除目标的类型，进行转化
//




//     // TODO: finish removeUtil
//        if ( head == nullptr)
//            return nullptr;
//        if ( x < head->key){
//            head->left = removeUtil(head->left,x);
//        }else if (x > head->key){
//            head->right = removeUtil(head->right,x);
//        }else {
//            if (head->left != nullptr && head->right != nullptr) {
//                node *parent = head->right;
//                while (parent->left != nullptr) {
//                    parent = parent->left;
//                }
//                head->key = parent->key;//右子树最小值放入被删节点位置
//                head->right = removeUtil(parent->right, parent->key);
//            } else if (head->left != nullptr) {
//                head = head->left;
//            } else if (head->right != nullptr) {
//                head = head->right;
//            } else {
//                return nullptr;
//            }
//        }
//        //删除完成，接下来看高度是否平衡
//        if(head == nullptr)
//            return nullptr;
////        head->height = 1+max(height(head->left), height(head->right));
//        if(height(head->left) - height(head->right) >= 2){
//            //相当于插入在左子树上
//            if(height(head->left->left) - height(head->left->right) >= 2) {
//                //LL
//                return rightRotation(head);
//            }else {
//                //LR
//                return leftAndRightRotation(head);
//            }
//
//
//        } else if(height(head->right) - height(head->left) >= 2){
//            //相当于插入在右子树上
//            if(height(head->right->right) - height(head->right->left) >= 2) {
//                //RR
//                return leftRotation(head);
//            }else {
//                //RL
//                return rightAndLeftRotation(head);
//            }
//
//        } else{}
//        head->height=1+max(height(head->left), height(head->right));
//        return head;
//    }
//


    node * searchUtil(node * head, int x){
        if(head == nullptr) return nullptr;
        int k = head->key;
        if(k == x) return head;
        if(k > x) return searchUtil(head->left, x);
        if(k < x) return searchUtil(head->right, x);
    }


};




class BST{
    // TODO: finish BST according to AVL
public:
    node * root = nullptr;
    void insert(int x){
        root=insertBST(root, x);
    }

    void remove(int x){
        root=removeBST(root, x);
    }

    node * search(int x){
        return searchBST(root,x);
    }

    void inorder(){
        inorderBST(root);
        cout<<endl;
    }
    int height(node * head){
        if(head==nullptr) return 0;
        return head->height;
    }


// Traverse and print AVL tree
    void inorderBST(node * head){
        if(head==nullptr) return ;
        inorderBST(head->left);
        cout<<head->key<<" ";
        inorderBST(head->right);
    }
    node * searchBST(node * head, int x){
        if(head == nullptr) return nullptr;
        int k = head->key;
        if(k == x) return head;
        if(k > x) return searchBST(head->left, x);
        if(k < x) return searchBST(head->right, x);
    }
    node * insertBST(node * head, int x) {
        // TODO: finish insertUtil
        if (head == nullptr){
//            node<T> h =node<T>();
//            h.height = 1;
//            h.key = x;
//            h.left = NULL;
//            h.right = NULL;
//            node<T>* h2 =NULL;
//            *h2 =h;
//            return h2;
            head = new node();
            head->right = nullptr;
            head->left = nullptr;
            head->key = x;
            head->height = 1;
            return head;
        }
        if (head->key > x) {
            head->left = insertBST(head->left, x);
        } else if (head->key < x) {
            head->right = insertBST(head->right, x);
        } else{

        }
        head->height=1+max(height(head->left), height(head->right));
        return  head;

    }
    node * removeBST(node * head, int x){
        // TODO: finish removeUtil
        if ( head == nullptr)
            return nullptr;
        if ( x < head->key){
            head->left = removeBST(head->left,x);
        }else if (x > head->key){
            head->right = removeBST(head->right,x);
        }else{
            if(head->left != nullptr && head->right != nullptr){
                node * parent = head->right;
                while (parent->left != nullptr){
                    parent = parent->left;
                }
                head->key = parent->key;//右子树最小值放入被删节点位置
                head->right = removeBST(head->right,parent->key);
            } else if(head->left != nullptr){
                head = head->left;
            } else if(head->right != nullptr){
                head = head->right;
            }else{
                return nullptr;
            }

        }
        //删除完成
        head->height=1+max(height(head->left), height(head->right));
        return head;
    }

};



int main(){
    AVL avl;
    BST bst;
    static int randomArr[5000];
    srand(time(NULL));
    for (int i = 0; i < 5000; i++) {
        randomArr[i] = rand() % 5001;
        avl.insert(randomArr[i]);
        bst.insert(randomArr[i]);
    }




//      for(int i =0;i<5000;i++){
//        avl.remove(i);
//        bst.remove(i);
//      }









    avl.inorder();
    bst.inorder();
    cout<<"There are 5000 nodes in the tree"<<endl;
    cout<<"AVL Tree:"<<endl;
    cout<<"AVL Tree hight: "<<avl.height(avl.root)<<endl;
    cout<<"BST:"<<endl;
    cout<<"BST hight: "<<bst.height(bst.root)<<endl;


}

